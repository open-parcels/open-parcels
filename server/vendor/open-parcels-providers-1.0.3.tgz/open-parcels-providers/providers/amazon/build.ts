import {
  findCarrier,
  ignoredStatus,
  mapStatus,
  resolveStatus,
  type RawStatus,
  type Rules,
  snapshot,
  type ParcelSnapshot,
  type SnapshotEvent,
} from "../../provider/api.js";
import { arrivalWindow, parseClock, pastDay, placedDay, localIso, type Day } from "./dates.js";
import { shipmentKey, type OrderTile, type TrackPage } from "./pages.js";
import type { Storefront } from "./storefronts.js";
import { maskDigits } from "./text.js";

export const AMAZON_ID = "amazon";

/** Order lines that are no parcel (cancelled, refunded or returned): the table's ignore list. */
export function isSkipped(rules: Rules, statusText: string): boolean {
  return ignoredStatus(rules, AMAZON_ID, { text: statusText }) !== null;
}

export function readsAsStatus(rules: Rules, text: string): boolean {
  return isSkipped(rules, text) || mapStatus(rules, AMAZON_ID, { text }) !== null;
}

/** Amazon's own fleet never hands off. */
const OWN_FLEET_RE = /^(?:AMZ|AMAZON|AMZL|SWA)/i;

/** `PluginContext.reportUnknown`: keys and codes only, never personal data. */
export type Reporter = (kind: string, key: string) => void;

/**
 * The carrier a code names, `amazon` for Amazon's own fleet, or null when it is not known.
 * Amazon's carrier codes (DHL_DE, DPD_DE, ROYAL_MAIL) are names or aliases in the registry.
 */
export function carrierFor(rules: Rules, code: string | null, report: Reporter): string | null {
  if (code === null || OWN_FLEET_RE.test(code)) {
    return AMAZON_ID;
  }
  const known = findCarrier(rules, code.replaceAll("_", " "))?.id;
  if (known === undefined) {
    report("carrier_code", code);
    return null;
  }
  return known;
}

export interface BuildInput {
  readonly rules: Rules;
  readonly storefront: Storefront;
  readonly tiles: readonly OrderTile[];
  readonly track: TrackPage | null;
  readonly trackPath: string | null;
  readonly now: Date;
  readonly report: Reporter;
}

function history(input: BuildInput, timeZone: string): SnapshotEvent[] {
  const events: SnapshotEvent[] = [];
  for (const event of input.track?.events ?? []) {
    const day: Day | null = pastDay(input.rules, event.dateText, input.now, timeZone);
    if (day === null) {
      input.report("event_date", maskDigits(event.dateText));
      continue;
    }
    const clock = parseClock(event.timeText) ?? { hour: 0, minute: 0 };
    const mapped = mapStatus(input.rules, AMAZON_ID, { text: event.message });
    if (mapped === null) {
      input.report("event_text", maskDigits(event.message));
    }
    events.push({
      at: localIso(day, clock.hour, clock.minute, timeZone),
      status: mapped?.status ?? null,
      rawStatus: event.message,
      location: event.location,
    });
  }
  return events.sort((a, b) => Date.parse(b.at) - Date.parse(a.at));
}

/** The predicted window, cross-checked against the countdown to its end when the page has one. */
function plannedWindow(
  input: BuildInput,
  lead: OrderTile,
  timeZone: string,
): { from: string; to: string } | null {
  const promise = input.track?.promiseMessage ?? null;
  const fromPromise = arrivalWindow(input.rules, promise, input.now, timeZone);
  const countdown = input.track?.windowEndsInMs ?? null;
  if (fromPromise !== null) {
    const expectedEnd = input.now.getTime() + (countdown ?? 0);
    const plausible =
      countdown === null || Math.abs(Date.parse(fromPromise.to) - expectedEnd) <= 60 * 60_000;
    if (plausible) {
      return fromPromise;
    }
    input.report("delivery_window", maskDigits(promise ?? ""));
  }
  return arrivalWindow(input.rules, lead.statusText, input.now, timeZone);
}

function resolve(input: BuildInput, lead: OrderTile, events: readonly SnapshotEvent[]) {
  const milestone = input.track?.milestone ?? null;
  const shortStatus = input.track?.shortStatus ?? null;
  const fromShort =
    shortStatus === null ? null : mapStatus(input.rules, AMAZON_ID, { code: shortStatus });
  if (milestone !== null && mapStatus(input.rules, AMAZON_ID, { code: milestone }) === null) {
    input.report("milestone", milestone);
  }
  if (shortStatus !== null && fromShort === null) {
    input.report("short_status", shortStatus);
  }
  // Newest first: the milestone, then the page's short status, the timeline, the order line.
  const fallbacks: RawStatus[] = [
    ...(shortStatus === null ? [] : [{ code: shortStatus }]),
    ...events.map((event) => ({ text: event.rawStatus })),
    ...(lead.statusText === "" ? [] : [{ text: lead.statusText }]),
  ];
  const latest: RawStatus = milestone === null ? {} : { code: milestone };
  const resolved = resolveStatus(input.rules, AMAZON_ID, latest, fallbacks);
  if (resolved.source === "unknown" && lead.statusText !== "") {
    input.report("order_text", maskDigits(lead.statusText));
  }
  const pickup = resolved.status === "at_pickup_point" || fromShort?.pickup === true;
  return { status: resolved.status, pickup };
}

function deliveredAt(
  input: BuildInput,
  lead: OrderTile,
  events: readonly SnapshotEvent[],
  timeZone: string,
): string | null {
  const event = events.find((entry) => entry.status === "delivered");
  if (event !== undefined) {
    return event.at;
  }
  const day = pastDay(input.rules, lead.statusText, input.now, timeZone);
  return day === null ? null : localIso(day, 0, 0, timeZone);
}

/** The day the order line says the order was placed, at midnight in the storefront's zone. */
function placedAt(input: BuildInput, lead: OrderTile): string | null {
  const day = placedDay(lead.placedText);
  return day === null ? null : localIso(day, 0, 0, input.storefront.timeZone);
}

function pageUrl(storefront: Storefront, path: string): string {
  return new URL(path, `https://www.${storefront.domain}/`).toString();
}

/** One snapshot for one shipment: the first order line speaks for the shipment's status. */
export function buildSnapshot(input: BuildInput): ParcelSnapshot | null {
  const lead = input.tiles[0];
  if (lead === undefined) {
    return null;
  }
  const track = input.track;
  const timeZone = track?.timeZone ?? input.storefront.timeZone;
  const events = history(input, timeZone);
  const { status, pickup } = resolve(input, lead, events);
  const delivered = status === "delivered";
  const window = delivered ? null : plannedWindow(input, lead, timeZone);
  const key = shipmentKey(lead);
  const trackingId = track?.trackingId ?? null;
  const carrier =
    track === null ? AMAZON_ID : carrierFor(input.rules, track.carrierCode, input.report);
  const handoff =
    trackingId !== null && carrier !== null && carrier !== AMAZON_ID
      ? { carrier, trackingNumber: trackingId }
      : null;
  return snapshot({
    carrier: AMAZON_ID,
    trackingNumber: trackingId ?? key,
    status,
    rawStatus: events[0]?.rawStatus ?? (lead.statusText === "" ? null : lead.statusText),
    delivered,
    deliveredAt: delivered ? deliveredAt(input, lead, events, timeZone) : null,
    expectedFrom: window?.from ?? null,
    expectedTo: window?.to ?? null,
    pickup,
    url: pageUrl(input.storefront, input.trackPath ?? lead.path),
    history: events,
    items: input.tiles.map((tile) => ({
      title: tile.title,
      imageUrl: tile.imageUrl,
      url: null,
      externalId: tile.lineItemId === "" ? null : tile.lineItemId,
      quantity: null,
      price: null,
      currency: null,
    })),
    order: { shop: AMAZON_ID, orderNumber: lead.orderId, placedAt: placedAt(input, lead) },
    externalRef: `${lead.orderId}/${key}`,
    handoff,
    raw: {
      storefront: input.storefront.domain,
      shipment: key,
      milestone: track?.milestone ?? null,
      shortStatus: track?.shortStatus ?? null,
      carrierCode: track?.carrierCode ?? null,
      orderStatus: lead.statusText === "" ? null : lead.statusText,
    },
    live:
      trackingId !== null && carrier === AMAZON_ID && !delivered
        ? {
            ref: {
              trackingId,
              csrfToken: track?.csrfToken ?? null,
              callout: track?.callout ?? null,
            },
            mapShown: track?.mapShown ?? false,
          }
        : null,
  });
}
