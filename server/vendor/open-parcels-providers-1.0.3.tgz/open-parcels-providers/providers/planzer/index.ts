import { z } from "zod";
import { defineCarrier, type ParcelSnapshot, type ProviderContext } from "../../provider/api.js";
import { CARRIER_ID, TRACKING_HOST } from "./shared.js";
import { isPlausibleBarcode, lookUp, trackingSnapshot } from "./tracking.js";

const configSchema = z.looseObject({});
type Config = z.infer<typeof configSchema>;

/** Public tracking only: there is no account to sign in to. */
const secretSchema = z.null();
type Secret = z.infer<typeof secretSchema>;

async function track(context: ProviderContext<Config, Secret>, barcodes: readonly string[]) {
  const snapshots: ParcelSnapshot[] = [];
  const report = (key: string): void => {
    context.reportUnknown("status_text", key);
  };
  // One at a time: the host limiter paces them, and an error stops the run before more go out.
  for (const barcode of barcodes) {
    if (!isPlausibleBarcode(barcode)) {
      continue;
    }
    const raw = await lookUp(context.http, barcode);
    if (raw !== null) {
      snapshots.push(trackingSnapshot(raw, barcode, report));
    }
  }
  return { snapshots, complete: true };
}

export const planzer = defineCarrier<Config, Secret>({
  id: CARRIER_ID,
  configSchema,
  secretSchema,
  signIn: { type: "none" },
  http: {
    limits: {
      [TRACKING_HOST]: { intervalMs: 4_000, burst: 2 },
      "*": { intervalMs: 10_000, burst: 1 },
    },
  },
  track,
});
