import { z } from "zod";
import { defineCarrier, trackEach, type ProviderContext } from "../../provider/api.js";
import {
  CARRIER_ID,
  BARCODE_PATTERN,
  lookUp,
  TRACKING_HOST,
  trackingSnapshot,
} from "./tracking.js";

const configSchema = z.looseObject({});
type Config = z.infer<typeof configSchema>;
/** The public tracking needs no sign-in. */
const secretSchema = z.null();
type Secret = z.infer<typeof secretSchema>;

async function track(context: ProviderContext<Config, Secret>, barcodes: readonly string[]) {
  const report = (kind: string, key: string): void => {
    context.reportUnknown(kind, key);
  };
  // One at a time: the host limiter paces them, and an error stops the run before more go out.
  return trackEach(barcodes, BARCODE_PATTERN, async (barcode) => {
    const rows = await lookUp(context.http, barcode);
    return rows === null ? null : trackingSnapshot(barcode, rows, report);
  });
}

export const magyarPosta = defineCarrier<Config, Secret>({
  id: CARRIER_ID,
  configSchema,
  secretSchema,
  signIn: { type: "none" },
  http: {
    limits: {
      [TRACKING_HOST]: { intervalMs: 5_000, burst: 2 },
      "*": { intervalMs: 10_000, burst: 1 },
    },
  },
  track,
});
